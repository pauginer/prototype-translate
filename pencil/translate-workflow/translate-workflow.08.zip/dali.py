# -*- coding: utf-8 -*-
# dali: a mustache-based command line utility
# 
# Replaces placeholders from a template ("hello {{msg}}") in a file using an external message file ("msg=World").
# Example of use: python dali.py src.txt msgs.txt -o result.txt
# 
# Requires pystache:
# pip install pystache
# pystache-test

import argparse
import pystache

#Hempler function to mport messages:
def import_messages(msg_file):
    msgs = {}
    with open(msg_file) as f:
        for line in f:
           (key, val) = line.split('=',1)
           msgs[key] = val.strip().decode('utf-8')
    return msgs


#Parse arguments:

parser = argparse.ArgumentParser(description='Replace placeholders in a source file with a message file.')
parser.add_argument('input', metavar='INPUT',  help='file to replace its placeholders')
parser.add_argument('messages', metavar='MESSAGES',   help='file containing key-value pairs to replace')
parser.add_argument('-o', metavar='OUTPUT',   help='file to be generated as a result')

args = parser.parse_args()

input_file=args.input
msg_file=args.messages


#Import source
src=open(input_file,"r").read()

#Import messages:
msgs = import_messages(msg_file)

#Replace placeholders
result = pystache.render(src.decode('utf-8'), msgs)


#Save output
(input_name,input_extension)=input_file.rsplit('.',1)

output_file=input_name+'.output'
if input_extension:
    output_file +='.'+input_extension

if args.o:
    output_file = args.o

with open(output_file, "w") as text_file:
    text_file.write(result.encode('utf-8'))


