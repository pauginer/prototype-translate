#Available in: es,nl,fi,ml,ca,ru,hi,fr

LANG="es"

rm -rf $LANG
mkdir $LANG
cp bg.png $LANG
cp save-btn.png $LANG
cp translate-workflow.ep $LANG/translate-workflow-$LANG.ep


#header:
python dali.py header.svg messages/$LANG.txt -o $LANG/header.svg 
inkscape $LANG/header.svg -e $LANG/header.png

#msg1:
python dali.py msg1.svg messages/$LANG.txt -o $LANG/msg1.svg 
inkscape $LANG/msg1.svg -e $LANG/msg1.png

#msg1-trans:
python dali.py msg1-trans.svg messages/$LANG.txt -o $LANG/msg1-trans.svg 
inkscape $LANG/msg1-trans.svg -e $LANG/msg1-trans.png

#msg1-suggestion:
python dali.py msg1-suggestion.svg messages/$LANG.txt -o $LANG/msg1-suggestion.svg 
inkscape $LANG/msg1-suggestion.svg -e $LANG/msg1-suggestion.png

#msg2:
python dali.py msg2.svg messages/$LANG.txt -o $LANG/msg2.svg 
inkscape $LANG/msg2.svg -e $LANG/msg2.png

#msg2-trans:
python dali.py msg2-trans.svg messages/$LANG.txt -o $LANG/msg2-trans.svg 
inkscape $LANG/msg2-trans.svg -e $LANG/msg2-trans.png

#msg2-more:
python dali.py msg2-more.svg messages/$LANG.txt -o $LANG/msg2-more.svg 
inkscape $LANG/msg2-more.svg -e $LANG/msg2-more.png

#msg2-completed:
python dali.py msg2-completed.svg messages/$LANG.txt -o $LANG/msg2-completed.svg 
inkscape $LANG/msg2-completed.svg -e $LANG/msg2-completed.png

#msg2-cross:
python dali.py msg2-cross.svg messages/$LANG.txt -o $LANG/msg2-cross.svg 
inkscape $LANG/msg2-cross.svg -e $LANG/msg2-cross.png

#msg2-cross-trans:
python dali.py msg2-cross-trans.svg messages/$LANG.txt -o $LANG/msg2-cross-trans.svg 
inkscape $LANG/msg2-cross-trans.svg -e $LANG/msg2-cross-trans.png

#msg2-suggestion:
python dali.py msg2-suggestion.svg messages/$LANG.txt -o $LANG/msg2-suggestion.svg 
inkscape $LANG/msg2-suggestion.svg -e $LANG/msg2-suggestion.png

#msg2-cross-suggestion:
python dali.py msg2-cross-suggestion.svg messages/$LANG.txt -o $LANG/msg2-cross-suggestion.svg 
inkscape $LANG/msg2-cross-suggestion.svg -e $LANG/msg2-cross-suggestion.png

#msg3:
python dali.py msg3.svg messages/$LANG.txt -o $LANG/msg3.svg 
inkscape $LANG/msg3.svg -e $LANG/msg3.png

#msg3-comments:
python dali.py msg3-comments.svg messages/$LANG.txt -o $LANG/msg3-comments.svg 
inkscape $LANG/msg3-comments.svg -e $LANG/msg3-comments.png

#msg3-prev-trans
python dali.py msg3-prev-trans.svg messages/$LANG.txt -o $LANG/msg3-prev-trans.svg 
inkscape $LANG/msg3-prev-trans.svg -e $LANG/msg3-prev-trans.png


#msg4:
python dali.py msg4.svg messages/$LANG.txt -o $LANG/msg4.svg 
inkscape $LANG/msg4.svg -e $LANG/msg4.png

#msg4-diff:
python dali.py msg4-diff.svg messages/$LANG.txt -o $LANG/msg4-diff.svg 
inkscape $LANG/msg4-diff.svg -e $LANG/msg4-diff.png

#msg5-compact:
python dali.py msg5-compact.svg messages/$LANG.txt -o $LANG/msg5-compact.svg 
inkscape $LANG/msg5-compact.svg -e $LANG/msg5-compact.png

#msg5-compact-review:
python dali.py msg5-compact-review.svg messages/$LANG.txt -o $LANG/msg5-compact-review.svg 
inkscape $LANG/msg5-compact-review.svg -e $LANG/msg5-compact-review.png

#msg5-expanded:
python dali.py msg5-expanded.svg messages/$LANG.txt -o $LANG/msg5-expanded.svg 
inkscape $LANG/msg5-expanded.svg -e $LANG/msg5-expanded.png

#msg5-expanded-review:
python dali.py msg5-expanded-review.svg messages/$LANG.txt -o $LANG/msg5-expanded-review.svg 
inkscape $LANG/msg5-expanded-review.svg -e $LANG/msg5-expanded-review.png

#msg6:
python dali.py msg6.svg messages/$LANG.txt -o $LANG/msg6.svg 
inkscape $LANG/msg6.svg -e $LANG/msg6.png

#msg6-mod:
python dali.py msg6-mod.svg messages/$LANG.txt -o $LANG/msg6-mod.svg 
inkscape $LANG/msg6-mod.svg -e $LANG/msg6-mod.png


#msg-final:
python dali.py msg-final.svg messages/$LANG.txt -o $LANG/msg-final.svg 
inkscape $LANG/msg-final.svg -e $LANG/msg-final.png


#msg-initial:
python dali.py msg-initial.svg messages/$LANG.txt -o $LANG/msg-initial.svg 
inkscape $LANG/msg-initial.svg -e $LANG/msg-initial.png



#list-msg1-mod:
python dali.py list-msg1-mod.svg messages/$LANG.txt -o $LANG/list-msg1-mod.svg 
inkscape $LANG/list-msg1-mod.svg -e $LANG/list-msg1-mod.png

#PAGE TRANSLATION:
#page-list-msg
python dali.py page-list-msg.svg messages/$LANG.txt -o $LANG/page-list-msg.svg 
inkscape $LANG/page-list-msg.svg -e $LANG/page-list-msg.png

#page-chrome:
python dali.py page-chrome.svg messages/$LANG.txt -o $LANG/page-chrome.svg 
inkscape $LANG/page-chrome.svg -e $LANG/page-chrome.png

#page-box:
python dali.py page-box.svg messages/$LANG.txt -o $LANG/page-box.svg 
inkscape $LANG/page-box.svg -e $LANG/page-box.png

#page-box-outdated:
python dali.py page-box-outdated.svg messages/$LANG.txt -o $LANG/page-box-outdated.svg 
inkscape $LANG/page-box-outdated.svg -e $LANG/page-box-outdated.png


#page-mark-translate:
python dali.py page-mark-translate.svg messages/$LANG.txt -o $LANG/page-mark-translate.svg 
inkscape $LANG/page-mark-translate.svg -e $LANG/page-mark-translate.png

#page-mark-outdated:
python dali.py page-mark-outdated.svg messages/$LANG.txt -o $LANG/page-mark-outdated.svg 
inkscape $LANG/page-mark-outdated.svg -e $LANG/page-mark-outdated.png


#page-title:
python dali.py page-title.svg messages/$LANG.txt -o $LANG/page-title.svg 
inkscape $LANG/page-title.svg -e $LANG/page-title.png

#page-ve-title:
python dali.py page-ve-title.svg messages/$LANG.txt -o $LANG/page-ve-title.svg 
inkscape $LANG/page-ve-title.svg -e $LANG/page-ve-title.png

#page-ve1:
python dali.py page-ve1.svg messages/$LANG.txt -o $LANG/page-ve1.svg 
inkscape $LANG/page-ve1.svg -e $LANG/page-ve1.png

#page-ve1-ori:
python dali.py page-ve1-ori.svg messages/$LANG.txt -o $LANG/page-ve1-ori.svg 
inkscape $LANG/page-ve1-ori.svg -e $LANG/page-ve1-ori.png

#page-ve2:
python dali.py page-ve2.svg messages/$LANG.txt -o $LANG/page-ve2.svg 
inkscape $LANG/page-ve2.svg -e $LANG/page-ve2.png

#page-ve2-ori:
python dali.py page-ve2-ori.svg messages/$LANG.txt -o $LANG/page-ve2-ori.svg 
inkscape $LANG/page-ve2-ori.svg -e $LANG/page-ve2-ori.png

#page-ve2-trans:
python dali.py page-ve2-trans.svg messages/$LANG.txt -o $LANG/page-ve2-trans.svg 
inkscape $LANG/page-ve2-trans.svg -e $LANG/page-ve2-trans.png

#page-th-title:
python dali.py page-th-title.svg messages/$LANG.txt -o $LANG/page-th-title.svg 
inkscape $LANG/page-th-title.svg -e $LANG/page-th-title.png

#page-th-title-ori:
python dali.py page-th-title-ori.svg messages/$LANG.txt -o $LANG/page-th-title-ori.svg 
inkscape $LANG/page-th-title-ori.svg -e $LANG/page-th-title-ori.png

#page-th-title-trans:
python dali.py page-th-title-trans.svg messages/$LANG.txt -o $LANG/page-th-title-trans.svg 
inkscape $LANG/page-th-title-trans.svg -e $LANG/page-th-title-trans.png


#page-th1:
python dali.py page-th1.svg messages/$LANG.txt -o $LANG/page-th1.svg 
inkscape $LANG/page-th1.svg -e $LANG/page-th1.png

#page-th2:
python dali.py page-th2.svg messages/$LANG.txt -o $LANG/page-th2.svg 
inkscape $LANG/page-th2.svg -e $LANG/page-th2.png

#page-progress2:
python dali.py page-progress2.svg messages/$LANG.txt -o $LANG/page-progress2.svg 
inkscape $LANG/page-progress2.svg -e $LANG/page-progress2.png

#page-progress3:
python dali.py page-progress3.svg messages/$LANG.txt -o $LANG/page-progress3.svg 
inkscape $LANG/page-progress3.svg -e $LANG/page-progress3.png

#page-progress4:
python dali.py page-progress4.svg messages/$LANG.txt -o $LANG/page-progress4.svg 
inkscape $LANG/page-progress4.svg -e $LANG/page-progress4.png

